package com.autocontrol.app

data class Vehicle(
    val id: String = "",
    val customerName: String = "",
    val phone: String = "",
    val make: String = "",
    val model: String = "",
    val year: String = "",
    val plate: String = "",
    val currentKm: Long = 0,
    val beltDueKm: Long = 0,
    val beltDueDate: Long = 0,
    val notes: String = ""
) {
    fun kmDueSoon(thresholdKm: Long = 1000): Boolean =
        beltDueKm > 0 && beltDueKm - currentKm in 0..thresholdKm

    fun kmOverdue(): Boolean = beltDueKm > 0 && currentKm >= beltDueKm
}
