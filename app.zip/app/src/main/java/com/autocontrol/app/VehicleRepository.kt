package com.autocontrol.app

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.tasks.await

/**
 * Todos los teléfonos que inicien sesión y usen el mismo workspaceId
 * ven la misma colección en tiempo real.
 */
class VehicleRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val workspaceId: String = "TALLER_CONFIGURAR_ID"
) {
    private fun collection() =
        db.collection("workshops").document(workspaceId).collection("vehicles")

    suspend fun save(vehicle: Vehicle) {
        val id = vehicle.id.ifBlank { collection().document().id }
        collection().document(id).set(vehicle.copy(id = id)).await()
    }

    suspend fun delete(id: String) {
        collection().document(id).delete().await()
    }

    fun listen(onChange: (List<Vehicle>) -> Unit,
               onError: (Exception) -> Unit): ListenerRegistration {
        return collection().addSnapshotListener { snapshot, error ->
            if (error != null) {
                onError(error)
                return@addSnapshotListener
            }
            onChange(snapshot?.documents?.mapNotNull {
                it.toObject(Vehicle::class.java)
            } ?: emptyList())
        }
    }
}
