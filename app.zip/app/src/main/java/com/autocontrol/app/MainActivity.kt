package com.autocontrol.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AutoControlScreen() } }
    }
}

@Composable
fun AutoControlScreen() {
    val auth = remember { FirebaseAuth.getInstance() }
    val repo = remember { VehicleRepository() }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    var message by remember { mutableStateOf("Ingresá con la misma cuenta en los dos celulares.") }
    var vehicles by remember { mutableStateOf(emptyList<Vehicle>()) }

    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var plate by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var dueKm by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("") }

    DisposableEffect(signedIn) {
        val registration = if (signedIn) repo.listen(
            onChange = { vehicles = it },
            onError = { message = "Error de sincronización: ${it.localizedMessage}" }
        ) else null
        onDispose { registration?.remove() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("AUTO CONTROL", style = MaterialTheme.typography.headlineMedium)
        Text("Clientes, vehículos y recordatorios del taller")
        Spacer(Modifier.height(12.dp))

        if (!signedIn) {
            OutlinedTextField(email, { email = it }, label = { Text("Correo") },
                modifier = Modifier.fillMaxWidth())
            OutlinedTextField(password, { password = it }, label = { Text("Contraseña") },
                modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scope.launch {
                        try {
                            auth.signInWithEmailAndPassword(email.trim(), password).await()
                            signedIn = true
                            message = "Sesión iniciada."
                        } catch (e: Exception) { message = e.localizedMessage ?: "No se pudo ingresar." }
                    }
                }) { Text("Ingresar") }
                OutlinedButton(onClick = {
                    scope.launch {
                        try {
                            auth.createUserWithEmailAndPassword(email.trim(), password).await()
                            signedIn = true
                            message = "Cuenta creada. Usá esta misma cuenta en el otro celular."
                        } catch (e: Exception) { message = e.localizedMessage ?: "No se pudo crear la cuenta." }
                    }
                }) { Text("Crear cuenta") }
            }
            Text(message)
        } else {
            Row(horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()) {
                Text("Sincronización en la nube activa")
                TextButton(onClick = {
                    auth.signOut(); signedIn = false; vehicles = emptyList()
                }) { Text("Salir") }
            }
            Text(message)
            HorizontalDivider()
            Text("Nuevo vehículo", style = MaterialTheme.typography.titleLarge)
            @Composable fun field(value: String, change: (String) -> Unit, label: String) {
                OutlinedTextField(value, change, label = { Text(label) },
                    modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            field(customer, { customer = it }, "Nombre del cliente")
            field(phone, { phone = it }, "Teléfono")
            field(make, { make = it }, "Marca")
            field(model, { model = it }, "Modelo")
            field(year, { year = it }, "Año")
            field(plate, { plate = it }, "Patente")
            field(km, { km = it }, "Kilometraje actual")
            field(dueKm, { dueKm = it }, "Km del próximo cambio de correa")
            field(dueDate, { dueDate = it }, "Fecha próximo cambio (dd/MM/yyyy)")
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val current = km.toLongOrNull()
                    val target = dueKm.toLongOrNull()
                    val dateMillis = try {
                        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                            .parse(dueDate)?.time ?: 0L
                    } catch (_: Exception) { 0L }

                    if (customer.isBlank() || phone.isBlank() || make.isBlank() ||
                        model.isBlank() || current == null || target == null) {
                        message = "Completá cliente, teléfono, marca, modelo y kilometrajes válidos."
                    } else {
                        scope.launch {
                            try {
                                repo.save(Vehicle(
                                    customerName = customer, phone = phone, make = make,
                                    model = model, year = year, plate = plate,
                                    currentKm = current, beltDueKm = target,
                                    beltDueDate = dateMillis
                                ))
                                customer = ""; phone = ""; make = ""; model = ""
                                year = ""; plate = ""; km = ""; dueKm = ""; dueDate = ""
                                message = "Vehículo guardado y sincronizado."
                            } catch (e: Exception) {
                                message = e.localizedMessage ?: "No se pudo guardar."
                            }
                        }
                    }
                }
            ) { Text("GUARDAR EN LA NUBE") }

            Spacer(Modifier.height(12.dp))
            Text("Vehículos registrados (${vehicles.size})",
                style = MaterialTheme.typography.titleLarge)
            LazyColumn {
                items(vehicles, key = { it.id }) { v ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${v.make} ${v.model} ${v.year}",
                                style = MaterialTheme.typography.titleMedium)
                            Text("${v.customerName} · ${v.phone}")
                            Text("Patente: ${v.plate} · Actual: ${v.currentKm} km")
                            Text("Próxima correa: ${v.beltDueKm} km")
                            val status = when {
                                v.kmOverdue() -> "CORREA VENCIDA POR KILOMETRAJE"
                                v.kmDueSoon() -> "PRÓXIMA: menos de 1.000 km"
                                else -> "En seguimiento"
                            }
                            Text(status)
                            TextButton(onClick = {
                                scope.launch {
                                    try { repo.delete(v.id) }
                                    catch (e: Exception) { message = "No se pudo borrar: ${e.localizedMessage}" }
                                }
                            }) { Text("Eliminar") }
                        }
                    }
                }
            }
        }
    }
}
